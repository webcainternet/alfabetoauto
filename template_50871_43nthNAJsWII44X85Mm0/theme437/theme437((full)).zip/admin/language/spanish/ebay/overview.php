<?php
$_['lang_title']                    = 'OpenBay Pro para eBay';
$_['lang_heading']                  = 'Visión Gener de eBay';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Configuraciones';
$_['lang_heading_sync']             = 'Syncronizar';
$_['lang_heading_account']          = 'Mi cuenta';
$_['lang_heading_links']            = 'Enlaces del artículo';
$_['lang_heading_stock_report']     = 'Reporte del stock';
$_['lang_heading_item_import']      = 'Importar artículos';
$_['lang_heading_order_import']     = 'Importar pedidos';
$_['lang_heading_adds']             = 'Instalar complementos';
$_['lang_heading_summary']          = 'Resumen de eBay';
$_['lang_heading_profile']          = 'Perfiles';
$_['lang_heading_template']         = 'Templates';
$_['lang_heading_ebayacc']          = 'cuenta de eBay';
$_['lang_heading_register']         = 'Registrar aquí';
