<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Feed de productos';
$_['text_success']     = 'Éxito: has modificado el feed de Google Base!';

// Entry
$_['entry_status']     = 'Estatus:';
$_['entry_data_feed']  = 'Url feed de datos:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el feed de Google Base!';
?>
