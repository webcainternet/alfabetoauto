<?php
// Heading
$_['heading_title']  = 'Reporte de Productos Vistos';

// Text
$_['text_success']   = 'Éxito: has reseteado le reporte de productos vistos!';

// Column
$_['column_name']    = 'Nombre del Producto';
$_['column_model']   = 'Modelo';
$_['column_viewed']  = 'Visto';
$_['column_percent'] = 'Porcentaje';
?>
