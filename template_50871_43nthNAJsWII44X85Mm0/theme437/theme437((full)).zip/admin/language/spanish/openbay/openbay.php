<?php 
$_['heading_title']                     = 'eBay';
$_['text_edit']                         = 'Editar';
$_['text_install']                      = 'Instalar';
$_['text_uninstall']                    = 'Desinstalar';
$_['text_enabled']                      = 'Habilitar';
$_['text_disabled']                     = 'No habilitar';
$_['error_category_nosuggestions']      = 'No se pudieron cargar las categorías sugeridas';
$_['lang_text_success']                 = 'Has guardado tus cambios en la extensión de eBay';