<?php
$_['lang_title']                    = 'OpenBay Pro für eBay';
$_['lang_heading']                  = 'eBay Überblick';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Einstellungen';
$_['lang_heading_sync']             = 'Synchronisieren';
$_['lang_heading_account']          = 'Mein Konto';
$_['lang_heading_links']            = 'verbundene Artikel';
$_['lang_heading_stock_report']     = 'Lagerbericht';
$_['lang_heading_item_import']      = 'Artikel importieren';
$_['lang_heading_order_import']     = 'Aufträge importieren';
$_['lang_heading_adds']             = 'Installierte Add-Ons';
$_['lang_heading_summary']          = 'eBay Zusammenfassung';
$_['lang_heading_profile']          = 'Profile';
$_['lang_heading_template']         = 'Vorlagen';
$_['lang_heading_ebayacc']          = 'eBay Konto';
$_['lang_heading_register']         = 'Hier anmelden';
?>