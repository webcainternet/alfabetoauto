<?php
// Text
$_['text_subject']       = '%s - Retourenaktualisierung %s';
$_['text_return_id']     = 'Retourennummer:';
$_['text_date_added']    = 'Retourendatum:';
$_['text_return_status'] = 'Ihre Retoure hat jetzt den folgenden Status:';
$_['text_comment']       = 'Die Anmerkungen zu Ihrer Retoure sind:';
$_['text_footer']        = 'Bitte antworten Sie einfach auf diese E-Mail, falls Sie Fragen haben.';
?>