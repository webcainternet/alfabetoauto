HOW TO INSTALL/USE
------------------

Full install/use documentation :  http://www.oc-extensions.com/Facebook-Comments    (see Help Tab)
 