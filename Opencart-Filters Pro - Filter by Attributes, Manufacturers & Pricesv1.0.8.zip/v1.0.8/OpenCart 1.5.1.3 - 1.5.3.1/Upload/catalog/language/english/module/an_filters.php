<?php
// Heading 
$_['heading_title']  = 'Refine your search';

// Entries
$_['entry_price']  = 'Price';
$_['entry_manufacturer']  = 'Manufacturer';
$_['entry_to']  = 'to';

// Links
$_['link_clearFilter'] = 'Clear filter';
$_['link_go'] = 'Go';

?>