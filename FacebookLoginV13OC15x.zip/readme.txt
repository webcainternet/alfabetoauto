HOW TO INSTALL/USE
------------------

Full install/use documentation :  http://www.oc-extensions.com/Facebook-Login    (see Help Tab)
 